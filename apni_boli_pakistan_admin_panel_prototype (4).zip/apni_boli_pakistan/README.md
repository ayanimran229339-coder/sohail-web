# Apni Boli Pakistan — responsive storefront

## Run locally
1. Extract the ZIP.
2. Open `index.html` in a modern browser, or host the folder on a static web host.
3. Product photos use internet image URLs.

## Features
- Responsive desktop/mobile layout
- Product search, categories, sorting, wishlist and cart
- Purchase Now checkout form with JazzCash and Easypaisa selection UI
- Input validation and official merchant-resource links

## Important: payment is not live yet
The payment selection UI is prepared, but it does NOT initiate a real payment. Live payment requires approved merchant accounts and credentials from JazzCash and Easypaisa, a backend/server, server-side creation of each order, gateway-specific signed requests, return/callback handling, server-side transaction status verification, and a database. Never put merchant secrets in browser JavaScript and never ask customers to enter their wallet PIN/password on this website. Only mark orders paid after a trusted server-side verification response.

Official resources:
- JazzCash: https://corporateonboarding.jazzcash.com.pk/online-payment
- Easypaisa: https://merchantportal.easypaisa.com.pk/

Product prices in this demo are placeholders (Rs. 1); confirm actual pricing, delivery fees, returns and privacy terms before launch.
