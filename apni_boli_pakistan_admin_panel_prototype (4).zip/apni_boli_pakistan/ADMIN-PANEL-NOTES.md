# Admin Panel Prototype

Open `admin.html` to manage demo product/campaign records. This is a browser-local prototype only: records are stored in localStorage on the device/browser where they are entered. It is not a secure production admin panel and does not sync to the live store, other browsers, or a database.

This prototype supports product name, image, unique ID, amount (Rs. 50–80), target count, and a deadline duration. It does not process or verify payments, count paid entries, conduct/announce a random winner draw, or connect to JazzCash/Easypaisa. The deadline status becomes “Review required”; no draw is automatically run.

Before any real-money launch, obtain qualified local legal advice for the proposed paid-entry/prize model, then implement server-side authentication, database, storage, audited draw rules if legally approved, and an authorized payment integration. Never collect customer wallet OTP/MPIN on this site.
