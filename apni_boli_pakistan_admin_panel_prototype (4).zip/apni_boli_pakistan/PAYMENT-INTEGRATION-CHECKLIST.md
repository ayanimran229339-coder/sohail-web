# Gateway integration checklist

- Obtain approved merchant accounts for both providers.
- Deploy a backend over HTTPS (Node, PHP, Laravel, Django, etc.) and a database.
- Keep gateway merchant IDs, passwords, signing keys and salts in server environment variables only.
- Backend creates a pending order and computes the amount from trusted product/inventory data.
- Backend initiates the selected provider's documented hosted checkout flow.
- Validate request/response signatures exactly as the provider's current documentation requires.
- Treat browser return URLs as informational only; verify payment with the server-side status API or authenticated callback/webhook.
- Make callback processing idempotent and match merchant order ID, amount, currency and provider transaction reference.
- Mark order paid only after verification; store status, timestamps and provider references.
- Test success, decline, cancellation, pending, duplicate callback and timeout cases in sandbox before go-live.
